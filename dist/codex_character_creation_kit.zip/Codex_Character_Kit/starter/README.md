# 別キャラ制作用スターター

このフォルダが作業ルートです。同梱キットのinstructions、AGENTS.md、記入済み制作依頼シートを読んでください。

新キャラの画像をcharacter_materials/<新ID>/へ置き、projects/<新ID>/へ制作します。python -m live2d_ai initは一パーツの雛形を作るだけです。顔・髪・耳・口・目の分割とリグは別途必要です。

セットアップとコマンドは../instructions/07_開発環境セットアップ.md、最初の依頼は../instructions/01_Codexへの最初の指示.txtを参照してください。

元キャラ用の画像・専用マスク・全テスト・iPhone中継は未同梱。同梱tests/tracking.test.cjsはWebカメラの純粋な処理だけを検証します。
